/* eslint-env jquery, browser */
/* global $ */

$(() => {
  // Place JavaScript code here...
});
